﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Win32.SafeHandles;
using GENPORTCAL4_API.Models;
using System.Collections;
using Microsoft.Data.SqlClient;
// using System.Data.SqlClient;

namespace GENPORTCAL4_API.DataAccess.Interfaces
{
    public interface IGeneralDataCenter
    {
        public Task<(bool success, string message, T data)> Get<T>(string commandText, CommandType type, IEnumerable<Parameter> param = null, bool DBlink = false) where T : new();
        public Task<(bool success, string message, T data)> GetItems<T>(string commandText, CommandType type, IEnumerable<Parameter> param = null) where T : new();
        public Task<(bool success, string message)> Execute(string commandText, CommandType type, IEnumerable<Parameter> param = null,bool DBlink = false);
        public Task<(bool success, string message, T data)> QueryAsync<T>(string commandText, CommandType commandType, IEnumerable<SqlParameter> parameters = null, bool DBlink = false) where T : new();
        public Task<(bool success, string message, int numberRowsAffected)> ExecuteAsync(string commandText, CommandType commandType, IEnumerable<SqlParameter> parameters = null, bool DBlink = false);
        public Task<(bool success, string message, List<Parameter> data)> ExecuteStoredProcedure(string commandText, CommandType type, IEnumerable<StoredProcedure> param = null, bool DBlink = false);
        public Task<(bool success, string message)> ExecuteTransMSSql(ArrayList command);

        public SchemaDBModel SchemaDB();
        public SqlConnection GetOpenConnection();
        public Task<DataSet> GetOpenConnectionAD();
        public Task<SafeAccessTokenHandle> LogonDomain();
    }
}
