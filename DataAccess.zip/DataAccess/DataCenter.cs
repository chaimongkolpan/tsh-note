﻿using GENPORTCAL4_API.Common.Interfaces;
using GENPORTCAL4_API.DataAccess.Interfaces;
using GENPORTCAL4_API.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Win32.SafeHandles;
using Newtonsoft.Json;
using StackExchange.Redis;
using System.Collections;
using System.Data;
using System.Runtime.InteropServices;
using System.Security.Principal;

namespace GENPORTCAL4_API.DataAccess
{
    public class DataCenter : IDataCenter
    {
        private string _conStr;
        private readonly string _readonly = "ReadOnly";
        private readonly string _readwrite = "ReadWrite";
        private readonly string _domain;
        private readonly IConnectionMultiplexer _redis;
        private readonly IHttpContextAccessor _context;
        private readonly ICipher _cipher;
        const int LOGON32_PROVIDER_DEFAULT = 0;
        const int LOGON32_LOGON_INTERACTIVE = 2;
        public DataCenter(IConfiguration config, IConnectionMultiplexer redis, IHttpContextAccessor context, ICipher cipher)
        {
            _redis = redis;
            _cipher = cipher;
            _context = context;
            _conStr = config.GetConnectionString("DbContext");
            _domain = config.GetValue<string>("Domain");
        }

        public SchemaDBModel SchemaDB() => AppSetting.Configuration.GetSection("SchemaDB").Get<SchemaDBModel>();

        public SqlConnection GetOpenConnection()
        {
            try
            {
                SqlConnection connection = new();
                if (!string.IsNullOrEmpty(_context?.HttpContext?.Request?.Headers["AccessKey"].ToString()))//Check AuthorizeAD or Check AccessKey
                {
                    //var safeAccessTokenHandle = LogonDomain().Result;
                    using (var accessToken = LogonDomain().Result)
                    {
                        //WindowsIdentity.RunImpersonated(accessToken, new Action(() =>
                        //{
                        //    connection = new SqlConnection(this._conStr);
                        //    connection.Open();
                        //}));
                        //WindowsIdentity.RunImpersonated(accessToken, () =>
                        //{
                        //    using (connection = new SqlConnection(_conStr))
                        //    {
                        //        connection.Open();
                        //    }
                        //});

                        var action = new Action(() =>
                        {
                            using (connection = new SqlConnection(_conStr))
                            {
                                connection.Open();
                            }
                        });
                        WindowsIdentity.RunImpersonated(safeAccessTokenHandle: accessToken, action: action);
                    }

                    return connection;
                }
                else
                {
                    connection = new SqlConnection(this._conStr);
                    connection.Open();
                    return connection;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<DataSet> GetOpenConnectionAD()
        {
            var ds = new DataSet();
            var safeAccessTokenHandle = await LogonDomain();
#pragma warning disable CA1416 // Validate platform compatibility
            WindowsIdentity.RunImpersonated(safeAccessTokenHandle, new Action(() =>
            {
                using (SqlConnection _conn = new SqlConnection(_conStr))
                {
                    _conn.Open();
                    SqlDataAdapter sqlData = new SqlDataAdapter("SELECT 1", _conn);
                    sqlData.SelectCommand.CommandType = CommandType.Text;
                    _ = sqlData.Fill(ds);
                }
            }));
#pragma warning restore CA1416 // Validate platform compatibility

            if (ds.Tables.Count < 1 || ds.Tables[0].Rows.Count < 1) throw new InvalidOperationException($"Connect to DB Fail!!!");
            return await Task.FromResult(ds);
        }

        public async Task<SafeAccessTokenHandle> LogonDomain()
        {
            var cText = GetUserInfoFromRedis(_context.HttpContext.Request.Headers["AccessKey"].ToString());
            var userInfo = _cipher.Decrypt(cText).Split("||");
            if (userInfo[0] is null || userInfo[1] is null)
                throw new InvalidProgramException("Username or Password is invalid(isnull).");

            var userName = userInfo[0];
            var password = userInfo[1];
            bool methodStatus = LogonUser(userName, _domain, password, LOGON32_LOGON_INTERACTIVE, LOGON32_PROVIDER_DEFAULT, out SafeAccessTokenHandle safeAccessTokenHandle);

            if (!methodStatus)
                throw new InvalidProgramException($"Username or Password is invalid.");

            return await Task.FromResult(safeAccessTokenHandle);
        }

        public async Task<(bool success, string message, T data)> Get<T>(string commandText, CommandType type, IEnumerable<Parameter> param = null, bool DBlink = false) where T : new()
        {
            var result = new T();
            try
            {
                _ = CheckIsNullOrWhiteSpace(commandText);
                _conStr = _conStr.Replace(_readwrite, _readonly);
#if DEBUG
                var DS = _GetTest(commandText, type, param);
#else
				var DS = _Get(commandText, type, param);
#endif
                result = DataSetToList<T>(DS);
                return await Task.FromResult((true, "success", result));
            }
            catch (Exception ex)
            {
                return await Task.FromResult((false, ex.Message, result));
            }
        }

        public async Task<DataSet> Get(string commandText, CommandType type, IEnumerable<Parameter> param = null, bool DBlink = false)
        {
            var result = new DataSet();
            try
            {
                _ = CheckIsNullOrWhiteSpace(commandText);
                _conStr = _conStr.Replace(_readwrite, _readonly);
#if DEBUG
                var DS = _GetTest(commandText, type, param);
#else
				var DS = _Get(commandText, type, param);
#endif
                result = DS;
                return await Task.FromResult(result);
            }
            catch (Exception ex)
            {
                return await Task.FromResult(result);
            }
        }

        public DataSet _Get(string commandText, CommandType type, IEnumerable<Parameter> param = null)
        {
            DataSet DS = new DataSet();
            var cText = GetUserInfoFromRedis(_context.HttpContext.Request.Headers["AccessKey"].ToString());
            var userInfo = _cipher.Decrypt(cText).Split("||");
            if (userInfo[0] is null || userInfo[1] is null) throw new Exception("Username or Password is invalid(isnull).");

            bool methodStatus = LogonUser(userInfo[0],
                                            _domain,
                                            userInfo[1],
                                            LOGON32_LOGON_INTERACTIVE,
                                            LOGON32_PROVIDER_DEFAULT,
                                            out SafeAccessTokenHandle safeAccessTokenHandle);

            if (methodStatus)
            {
                WindowsIdentity.RunImpersonated(safeAccessTokenHandle, new Action(
                () =>
                {
                    using (SqlConnection _conn = new SqlConnection(_conStr))
                    {
                        _conn.Open();
                        SqlDataAdapter sqlData = new SqlDataAdapter(commandText, _conn);
                        sqlData.SelectCommand.CommandType = type;
                        if (param != null && param.Any())
                        {
                            foreach (var p in param)
                            {
                                sqlData.SelectCommand.Parameters.AddWithValue(p.Name, p.Value);
                            }
                        }
                        sqlData.Fill(DS);
                    }
                }));
            }
            else
            {
                throw new Exception($"Username or Password is invalid.");
            }

            if (DS.Tables.Count < 1 || DS.Tables[0].Rows.Count < 1) throw new Exception($"Data not found ({userInfo[0]})");

            return DS;
        }

        public DataSet _GetTest(string commandText, CommandType type, IEnumerable<Parameter> param = null) // for test on localhost
        {
            DataSet DS = new DataSet();
            using (SqlConnection _conn = new SqlConnection(_conStr))
            {
                _conn.Open();
                SqlDataAdapter sqlData = new SqlDataAdapter(commandText, _conn);
                sqlData.SelectCommand.CommandType = type;
                if (param != null && param.Any())
                {
                    foreach (var p in param)
                    {
                        sqlData.SelectCommand.Parameters.AddWithValue(p.Name, p.Value);
                    }
                }
                sqlData.Fill(DS);
            }
            if (DS.Tables.Count < 1 || DS.Tables[0].Rows.Count < 1) throw new Exception($"Data not found.");

            return DS;
        }

        private T DataSetToList<T>(DataSet DS) where T : new()
        {
            var result = new T();
            if (result is IList && result.GetType().IsGenericType)
            {
                result = ConvertToModel<T>(DS.Tables[0]);
            }
            else
            {
                result = ConvertToModel<List<T>>(DS.Tables[0]).FirstOrDefault();
            }
            return result;
        }

        public async Task<(bool success, string message)> Execute(string commandText, CommandType type, IEnumerable<Parameter> param = null, bool DBlink = false)
        {
            (bool success, string message) result;
            try
            {
                _ = CheckIsNullOrWhiteSpace(commandText);
                _conStr = _conStr.Replace(_readonly, _readwrite);
#if DEBUG
                var afrows = await _ExecuteTest(commandText, type, param);
#else
				var afrows = await _Execute(commandText, type, param);
#endif
                if (afrows > 0) result = (true, "success");
                else result = (true, "The command was executed but 0 row affected.");
            }
            catch (Exception ex)
            {
                result = (false, ex.Message);
            }
            return await Task.FromResult(result);
        }

        public async Task<int> _Execute(string commandText, CommandType type, IEnumerable<Parameter> param = null)
        {
            int afrows = 0;
            List<StoredProcedure> ListParameter = new List<StoredProcedure>();
            var cText = GetUserInfoFromRedis(_context.HttpContext?.Request.Headers["AccessKey"].ToString());
            var userInfo = _cipher.Decrypt(cText).Split("||");
            if (userInfo[0] is null || userInfo[1] is null) throw new Exception("Username or Password is invalid(isnull).");

            bool methodStatus = LogonUser(userInfo[0],
                                            _domain,
                                            userInfo[1],
                                            LOGON32_LOGON_INTERACTIVE,
                                            LOGON32_PROVIDER_DEFAULT,
                                            out SafeAccessTokenHandle safeAccessTokenHandle);

            if (methodStatus)
            {
                WindowsIdentity.RunImpersonated(safeAccessTokenHandle, new Action(
                () =>
                {
                    using (SqlConnection _conn = new SqlConnection(_conStr))
                    {
                        //SqlTransaction transaction;
                        _conn.Open();
                        //SqlTransaction transaction = _conn.BeginTransaction();
                        try
                        {
                            //SqlCommand sqlCmd = new SqlCommand(commandText, _conn, transaction);
                            SqlCommand sqlCmd = new SqlCommand(commandText, _conn);
                            sqlCmd.CommandType = type;
                            if (param != null && param.Any()) param.ToList().ForEach(p => sqlCmd.Parameters.AddWithValue(p.Name, p.Value));
                            afrows = sqlCmd.ExecuteNonQuery();
                            // transaction.Commit();
                        }
                        catch (SqlException sqlError)
                        {
                            throw sqlError;
                            // transaction.Rollback();
                        }
                        _conn.Close();
                    }
                }));
                return await Task.FromResult(afrows);
            }
            else
            {
                throw new Exception($"Username or Password is invalid.");
            }
        }

        public async Task<(int afrows, List<Parameter> data)> _ExecuteSP(string commandText, CommandType type, IEnumerable<StoredProcedure> param = null)
        {
            int afrows = 0;
            List<Parameter> ListParameter = new List<Parameter>();
            List<Parameter> data = new List<Parameter>();
            var cText = GetUserInfoFromRedis(_context.HttpContext.Request.Headers["AccessKey"].ToString());
            var userInfo = _cipher.Decrypt(cText).Split("||");
            if (userInfo[0] is null || userInfo[1] is null) throw new Exception("Username or Password is invalid(isnull).");

            bool methodStatus = LogonUser(userInfo[0],
                                            _domain,
                                            userInfo[1],
                                            LOGON32_LOGON_INTERACTIVE,
                                            LOGON32_PROVIDER_DEFAULT,
                                            out SafeAccessTokenHandle safeAccessTokenHandle);

            if (methodStatus)
            {
                WindowsIdentity.RunImpersonated(safeAccessTokenHandle, new Action(
                () =>
                {
                    using (SqlConnection _conn = new SqlConnection(_conStr))
                    {
                        //SqlTransaction transaction;
                        _conn.Open();
                        //SqlTransaction transaction = _conn.BeginTransaction();
                        try
                        {
                            //SqlCommand sqlCmd = new SqlCommand(commandText, _conn, transaction);
                            SqlCommand sqlCmd = new SqlCommand(commandText, _conn);
                            sqlCmd.CommandType = type;
                            if (param != null && param.Any())
                            {
                                param.ToList().ForEach(p =>
                                {
                                    if (!p.OutPut)
                                    {
                                        sqlCmd.Parameters.AddWithValue(p.Name, p.Value);
                                    }
                                    else
                                    {
                                        sqlCmd.Parameters.Add(new SqlParameter(p.Name, SqlDbType.VarChar, 500) { Direction = ParameterDirection.Output });
                                        ListParameter.Add(new Parameter { Name = p.Name });
                                    }
                                });

                            }
                            afrows = sqlCmd.ExecuteNonQuery();
                            if (ListParameter.Any())
                            {
                                ListParameter.ForEach(l =>
                                {
                                    l.Value = sqlCmd.Parameters[l.Name].Value;
                                });
                                data = ListParameter;
                            }
                            // transaction.Commit();
                        }
                        catch (SqlException sqlError)
                        {
                            throw sqlError;
                            // transaction.Rollback();
                        }
                        _conn.Close();
                    }
                }));
                return await Task.FromResult((afrows, data));
            }
            else
            {
                throw new Exception($"Username or Password is invalid.");
            }
        }

        public async Task<int> _ExecuteTest(string commandText, CommandType type, IEnumerable<Parameter> param = null) // for test on localhost
        {
            int afrows = 0;
            using (SqlConnection _conn = new SqlConnection(_conStr))
            {
                _conn.Open();
                //SqlTransaction transaction = _conn.BeginTransaction();
                try
                {
                    SqlCommand sqlCmd = new SqlCommand(commandText, _conn);
                    sqlCmd.CommandType = type;
                    if (param != null && param.Any()) param.ToList().ForEach(p => sqlCmd.Parameters.AddWithValue(p.Name, p.Value));
                    afrows = sqlCmd.ExecuteNonQuery();
                    // transaction.Commit();
                }
                catch (SqlException sqlError)
                {
                    throw sqlError;
                    // transaction.Rollback();
                }
                _conn.Close();
            }
            return await Task.FromResult(afrows);
        }

        private string GetUserInfoFromRedis(string key)
        {
            var cypherText = _redis.GetDatabase().StringGet(key);
            if (!cypherText.HasValue) throw new RedisException("Access key not found on redis.");
            return cypherText;
        }

        private T ConvertToModel<T>(object dt)
        {
            JsonSerializerSettings settings = new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore,
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore,
                FloatFormatHandling = FloatFormatHandling.DefaultValue,
            };
            var strDt = JsonConvert.SerializeObject(dt);
            return JsonConvert.DeserializeObject<T>(strDt, settings);
        }

        [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern bool LogonUser(string lpszUsername, string lpszDomain, string lpszPassword, int dwLogonType, int dwLogonProvider, out SafeAccessTokenHandle phToken);

        public async Task<(bool success, string message, T data)> GetItems<T>(string commandText, CommandType type, IEnumerable<Parameter> param = null) where T : new()
        {
            var result = new T();
            try
            {
#if DEBUG
                var DS = await GetItemsByLocal(commandText, type, param);
#else
                var DS = await GetItemsByImpersonated(commandText, type, param);
#endif
                result = DataSetToList<T>(DS);
                return await Task.FromResult((true, "success", result));
            }
            catch (Exception ex)
            {
                return await Task.FromResult((false, ex.Message, result));
            }
        }

        private async Task<DataSet> GetItemsByLocal(string commandText, CommandType type, IEnumerable<Parameter> param = null) // for test on localhost
        {
            DataSet DS = new DataSet();
            using (SqlConnection _conn = new SqlConnection(_conStr))
            {
                _conn.Open();
                SqlDataAdapter sqlData = new SqlDataAdapter(commandText, _conn);
                sqlData.SelectCommand.CommandType = type;
                if (param != null && param.Any())
                {
                    foreach (var p in param)
                    {
                        sqlData.SelectCommand.Parameters.AddWithValue(p.Name, p.Value);
                    }
                }
                sqlData.Fill(DS);
            }
            return await Task.FromResult(DS);
        }

        private async Task<DataSet> GetItemsByImpersonated(string commandText, CommandType type, IEnumerable<Parameter> param = null)
        {
            DataSet DS = new DataSet();
            var cText = GetUserInfoFromRedis(_context.HttpContext.Request.Headers["AccessKey"].ToString());
            var userInfo = _cipher.Decrypt(cText).Split("||");
            if (userInfo[0] is null || userInfo[1] is null)
                throw new InvalidProgramException("Username or Password is invalid(isnull).");

            var userName = userInfo[0];
            var password = userInfo[1];
            bool methodStatus = LogonUser(userName, _domain, password, LOGON32_LOGON_INTERACTIVE, LOGON32_PROVIDER_DEFAULT, out SafeAccessTokenHandle safeAccessTokenHandle);

            if (!methodStatus)
                throw new InvalidProgramException($"Username or Password is invalid.");

            WindowsIdentity.RunImpersonated(safeAccessTokenHandle, new Action(
                () =>
                {
                    using (SqlConnection _conn = new SqlConnection(_conStr))
                    {
                        _conn.Open();
                        SqlDataAdapter sqlData = new SqlDataAdapter(commandText, _conn);
                        sqlData.SelectCommand.CommandType = type;
                        if (param != null && param.Any())
                        {
                            foreach (var p in param)
                            {
                                sqlData.SelectCommand.Parameters.AddWithValue(p.Name, p.Value);
                            }
                        }
                        sqlData.Fill(DS);
                    }
                }));

            return await Task.FromResult(DS);
        }

        public async Task<(bool success, string message, T data)> QueryAsync<T>(string commandText, CommandType commandType, IEnumerable<SqlParameter> parameters = null, bool DBlink = false) where T : new()
        {
            var result = new T();
            try
            {
#if DEBUG
                var DS = await QueryByLocal(commandText, commandType, parameters, DBlink);
#else
                var DS = await QueryByImpersonated(commandText, commandType, parameters,DBlink);
#endif
                result = DataSetToList<T>(DS);
                return await Task.FromResult((true, "success", result));
            }
            catch (Exception ex)
            {
                return await Task.FromResult((false, ex.Message, result));
            }
        }

        private async Task<DataSet> QueryByLocal(string commandText, CommandType commandType, IEnumerable<SqlParameter> parameters = null, bool DBlink = false)
        {
            DataSet DS = new DataSet();
            using (var connection = GetOpenConnection())
            {
                SqlDataAdapter adapter = new SqlDataAdapter(commandText, connection);
                adapter.SelectCommand.CommandType = commandType;
                if (parameters != null && parameters.Any())
                {
                    adapter.SelectCommand.Parameters.AddRange(parameters.ToArray());
                }

                adapter.Fill(DS);
            }
            return await Task.FromResult(DS);
        }

        private async Task<DataSet> QueryByImpersonated(string commandText, CommandType commandType, IEnumerable<SqlParameter> parameters = null, bool DBlink = false)
        {
            DataSet DS = new DataSet();
            var cText = GetUserInfoFromRedis(_context.HttpContext.Request.Headers["AccessKey"].ToString());
            var userInfo = _cipher.Decrypt(cText).Split("||");
            if (userInfo[0] is null || userInfo[1] is null)
                throw new InvalidProgramException("Username or Password is invalid(isnull).");

            var userName = userInfo[0];
            var password = userInfo[1];
            bool methodStatus = LogonUser(userName, _domain, password, LOGON32_LOGON_INTERACTIVE, LOGON32_PROVIDER_DEFAULT, out SafeAccessTokenHandle safeAccessTokenHandle);

            if (!methodStatus)
                throw new InvalidProgramException($"Username or Password is invalid.");

            WindowsIdentity.RunImpersonated(safeAccessTokenHandle, new Action(
                () =>
                {
                    using (var connection = GetOpenConnection())
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter(commandText, connection);
                        adapter.SelectCommand.CommandType = commandType;
                        if (parameters != null && parameters.Any())
                        {
                            adapter.SelectCommand.Parameters.AddRange(parameters.ToArray());
                        }

                        adapter.Fill(DS);
                    }
                }));

            return await Task.FromResult(DS);
        }

        public async Task<(bool success, string message, int numberRowsAffected)> ExecuteAsync(string commandText, CommandType commandType, IEnumerable<SqlParameter> parameters = null, bool DBlink = false)
        {
            (bool success, string message, int numberRowsAffected) result;
            try
            {
                _conStr = _conStr.Replace(_readonly, _readwrite);
                int numberRowsAffected = 0;
#if DEBUG
                using (var connection = GetOpenConnection())
                {
                    SqlCommand cmd = new SqlCommand(commandText, connection);
                    cmd.CommandType = commandType;
                    if (parameters != null && parameters.Any())
                    {
                        cmd.Parameters.AddRange(parameters.ToArray());
                    }

                    numberRowsAffected = await cmd.ExecuteNonQueryAsync();
                }
#else
                var cText = GetUserInfoFromRedis(_context.HttpContext.Request.Headers["AccessKey"].ToString());
                var userInfo = _cipher.Decrypt(cText).Split("||");
                if (userInfo[0] is null || userInfo[1] is null) 
                    throw new InvalidProgramException("Username or Password is invalid(isnull).");

                var userName = userInfo[0];
                var password = userInfo[1];
                bool methodStatus = LogonUser(userName, _domain, password, LOGON32_LOGON_INTERACTIVE, LOGON32_PROVIDER_DEFAULT, out SafeAccessTokenHandle safeAccessTokenHandle);

                if (!methodStatus)
                    throw new InvalidProgramException($"Username or Password is invalid.");

                WindowsIdentity.RunImpersonated(safeAccessTokenHandle, new Action(
                    async () =>
                    {
                        using (var connection = GetOpenConnection())
                        {
                            SqlCommand cmd = new SqlCommand(commandText, connection);
                            cmd.CommandType = commandType;
                            if (parameters != null && parameters.Any())
                            {
                                cmd.Parameters.AddRange(parameters.ToArray());
                            }
                            // Support AS400 DBlink
                           
                            numberRowsAffected = await cmd.ExecuteNonQueryAsync();
                        }
                    }));
#endif
                if (numberRowsAffected > 0) result = (true, $"{numberRowsAffected} rows affected.", numberRowsAffected);
                else result = (true, $"The command was executed but {numberRowsAffected} row affected.", numberRowsAffected);
            }
            catch (Exception ex)
            {
                result = (false, ex.Message, 0);
            }
            return await Task.FromResult(result);
        }

        public async Task<(bool success, string message, List<Parameter> data)> ExecuteStoredProcedure(string commandText, CommandType type, IEnumerable<StoredProcedure> param = null, bool DBlink = false)
        {
            (bool success, string message, List<Parameter> data) response;
            response.data = new List<Parameter>();

            try
            {
                _ = CheckIsNullOrWhiteSpace(commandText);
                _conStr = _conStr.Replace(_readonly, _readwrite);
#if DEBUG
                var resp = await _ExecuteTestSP(commandText, type, param);
                response.data = resp.data;
#else
				var resp = await _ExecuteSP(commandText, type, param);
                response.data = resp.data;
#endif
                if (resp.afrows > 0)
                {
                    response.success = true;
                    response.message = "success";
                }
                else
                {
                    response.success = false;
                    response.message = "The command was executed but 0 row affected.";
                }
            }
            catch (Exception ex)
            {
                response.success = false;
                response.message = ex.Message.ToString();
            }
            return await Task.FromResult(response);
        }

        public async Task<(int afrows, List<Parameter> data)> _ExecuteTestSP(string commandText, CommandType type, IEnumerable<StoredProcedure> param = null) // for test on localhost
        {
            int afrows = 0;
            List<Parameter> ListParameter = new List<Parameter>();
            List<Parameter> data = new List<Parameter>();
            using (SqlConnection _conn = new SqlConnection(_conStr))
            {
                _conn.Open();
                //SqlTransaction transaction = _conn.BeginTransaction();
                try
                {
                    SqlCommand sqlCmd = new SqlCommand(commandText, _conn);
                    sqlCmd.CommandType = type;
                    sqlCmd.CommandTimeout = 300;
                    if (param != null && param.Any())
                    {
                        param.ToList().ForEach(p =>
                        {
                            if (!p.OutPut)
                            {
                                sqlCmd.Parameters.AddWithValue(p.Name, p.Value);
                            }
                            else
                            {
                                sqlCmd.Parameters.Add(new SqlParameter(p.Name, SqlDbType.VarChar, 500) { Direction = ParameterDirection.Output });
                                ListParameter.Add(new Parameter { Name = p.Name });
                            }
                        });
                    }
                    afrows = sqlCmd.ExecuteNonQuery();
                    if (ListParameter.Any())
                    {
                        ListParameter.ForEach(l =>
                        {
                            l.Value = sqlCmd.Parameters[l.Name].Value;
                        });
                        data = ListParameter;
                    }
                    // transaction.Commit();
                }
                catch (SqlException sqlError)
                {
                    throw sqlError;
                    // transaction.Rollback();
                }
                _conn.Close();
            }
            return await Task.FromResult((afrows, data));
        }

        public async Task<(bool success, string message)> ExecuteTransMSSql(ArrayList command)
        {
            (bool success, string message) result;
            try
            {
                //if (command.Count <= 0)
                //{
                //    throw new ArgumentException($"command cannot be null or whitespace.");
                //}
                command.ToArray().ToList().ForEach(p =>
                {
                    var sqlCmd = (SqlCommand)p;
                    _ = CheckIsNullOrWhiteSpace(sqlCmd?.CommandText);
                });
                _conStr = _conStr.Replace(_readonly, _readwrite);
#if DEBUG
                var afrows = await _ExecuteTransMSSqlTest(command);
#else
                var afrows = await _ExecuteTransMSSql(command);
#endif
                if (afrows) result = (true, "success");
                else result = (true, "The command was executed but 0 row affected.");
            }
            catch (Exception ex)
            {
                result = (false, ex.Message);
            }
            return await Task.FromResult(result);
        }

        public async Task<bool> _ExecuteTransMSSqlTest(ArrayList objCommand) // for test on localhost
        {
            bool afrows = false;
            using (SqlConnection _conn = new SqlConnection(_conStr))
            {
                _conn.Open();
                SqlTransaction transaction = _conn.BeginTransaction();
                try
                {
                    foreach (object cmd in objCommand)
                    {
                        SqlCommand sqlCmd = (SqlCommand)cmd;
                        sqlCmd.Connection = _conn;
                        sqlCmd.Transaction = transaction;
                        sqlCmd.ExecuteNonQuery();
                    }
                    transaction.Commit();
                    afrows = true;
                }
                catch (SqlException sqlError)
                {
                    transaction.Rollback();
                    afrows = false;
                    throw sqlError;
                }
                _conn.Close();
            }
            return await Task.FromResult(afrows);
        }

        public async Task<bool> _ExecuteTransMSSql(ArrayList objCommand)
        {
            bool afrows = false;
            List<StoredProcedure> ListParameter = new List<StoredProcedure>();
            var cText = GetUserInfoFromRedis(_context.HttpContext.Request.Headers["AccessKey"].ToString());
            var userInfo = _cipher.Decrypt(cText).Split("||");
            if (userInfo[0] is null || userInfo[1] is null) throw new Exception("Username or Password is invalid(isnull).");

            bool methodStatus = LogonUser(userInfo[0],
                                            _domain,
                                            userInfo[1],
                                            LOGON32_LOGON_INTERACTIVE,
                                            LOGON32_PROVIDER_DEFAULT,
                                            out SafeAccessTokenHandle safeAccessTokenHandle);

            if (methodStatus)
            {
                WindowsIdentity.RunImpersonated(safeAccessTokenHandle, new Action(
                () =>
                {
                    using (SqlConnection _conn = new SqlConnection(_conStr))
                    {
                        _conn.Open();
                        SqlTransaction transaction = _conn.BeginTransaction();
                        try
                        {
                            foreach (object cmd in objCommand)
                            {
                                SqlCommand sqlCmd = (SqlCommand)cmd;
                                sqlCmd.Connection = _conn;
                                sqlCmd.Transaction = transaction;
                                sqlCmd.ExecuteNonQuery();
                            }
                            transaction.Commit();
                            afrows = true;
                        }
                        catch (SqlException sqlError)
                        {
                            transaction.Rollback();
                            afrows = false;
                            throw sqlError;
                        }
                        _conn.Close();
                    }
                }));
                return await Task.FromResult(afrows);
            }
            else
            {
                throw new Exception($"Username or Password is invalid.");
            }
        }
        private bool CheckIsNullOrWhiteSpace(string commandText)
        {
            if (string.IsNullOrWhiteSpace(commandText)) throw new ArgumentException($"'{nameof(commandText)}' cannot be null or whitespace.", nameof(commandText));
            return false;
        }
    }

    public class Parameter
    {
        public string Name { get; set; }
        public object Value { get; set; }
    }

    public class StoredProcedure : Parameter
    {
        public bool OutPut { get; set; }
    }

    public class ResponseStoredProcedure
    {
        public int afrows { get; set; }
        public Boolean success { get; set; }
        public string message { get; set; }
        public List<ListStoredProcedure> data { get; set; }
    }

    public class ListStoredProcedure
    {
        public string Name { get; set; }
        public object Value { get; set; }
    }
}


